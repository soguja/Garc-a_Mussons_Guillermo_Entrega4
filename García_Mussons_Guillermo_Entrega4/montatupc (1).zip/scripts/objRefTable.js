const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.DragnDrop,
		C3.Plugins.Text,
		C3.Behaviors.DragnDrop.Cnds.OnDrop,
		C3.Plugins.Sprite.Cnds.IsOverlapping,
		C3.Plugins.Sprite.Acts.SetPos,
		C3.Behaviors.DragnDrop.Acts.SetEnabled,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.System.Cnds.CompareVar,
		C3.Plugins.Text.Acts.SetVisible
	];
};
self.C3_JsPropNameTable = [
	{ArrastrarYSoltar: 0},
	{atx_case: 0},
	{cpu: 0},
	{cpu_cooler: 0},
	{grafica: 0},
	{psu: 0},
	{placa_base: 0},
	{ram: 0},
	{Variable1: 0},
	{textofinal: 0},
	{PiezasColocadas: 0}
];

self.InstanceType = {
	atx_case: class extends self.ISpriteInstance {},
	cpu: class extends self.ISpriteInstance {},
	cpu_cooler: class extends self.ISpriteInstance {},
	grafica: class extends self.ISpriteInstance {},
	psu: class extends self.ISpriteInstance {},
	placa_base: class extends self.ISpriteInstance {},
	ram: class extends self.ISpriteInstance {},
	textofinal: class extends self.ITextInstance {}
}